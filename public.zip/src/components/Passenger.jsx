import React from 'react'

const Passenger = () => {
  return (
    <div>Passenger</div>
  )
}

export default Passenger